package com.example.ozgurozdemir.test;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;

public class MainActivity extends AppCompatActivity {

    private ImageView logo,logoWhite, background;
    Animation animation,animationAlpha;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        File myDB = getApplication().getFilesDir();
        final String path = myDB +  "/" + "BusDB";

        Database db = new Database(path);
        db.createDB();
        db.populateDB();

        //File data = new File(getFilesDir(), "BusDB");
        //data.delete();

        animation = AnimationUtils.loadAnimation(this, R.anim.anim);
        animationAlpha = AnimationUtils.loadAnimation(this, R.anim.white);

        logo = (ImageView) findViewById(R.id.logo);
        logoWhite = (ImageView) findViewById(R.id.logowhite);
        background = (ImageView) findViewById(R.id.background);
        logoWhite.setAnimation(animationAlpha);
        logo.setAnimation(animation);

        animation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                logo.getBackground().setAlpha(0);
                logoWhite.getBackground().setAlpha(0);
                background.setBackgroundColor(Color.WHITE);
                Intent i = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(i);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        getSupportActionBar().hide();

    }


}
