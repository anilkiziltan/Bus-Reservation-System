package com.example.ozgurozdemir.test;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;

public class RoundTripBuyActivity extends AppCompatActivity {

    TextView roundTripSeatTxt;
    private Button seatButton, cancelButton;
    private ListView availableTicketsDept, availableTicketsArr;
    private int personNumber = 0;
    private String selected = "";
    private String clientName;

    private TextView roundTripfromTextDept, roundTriptoTextDept ,roundTripDateTextDept, roundTripfromTextArr,
            roundTriptoTextArr, roundTripDateTextArr;

    ArrayList<Bus> arrayOfBuses = new ArrayList<Bus>();
    ArrayList<Bus> arrayOfBusesArr = new ArrayList<Bus>();

    private Database database;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_round_trip_buy);
        setTitle("Select Seat");

        final Intent intent = getIntent();
        personNumber = Integer.parseInt(intent.getStringExtra("personNumber"));

        File myDB = getApplication().getFilesDir();
        final String path = myDB +  "/" + "BusDB";
        database = new Database(path);

        clientName = intent.getStringExtra("clientName");

        roundTripSeatTxt = (TextView) findViewById(R.id.roundTripSeatTxt);
        roundTripSeatTxt.setText(String.format("*You have %s more seat to select", (personNumber*2)));

        roundTripfromTextDept = (TextView) findViewById(R.id.roundTripfromTextDept);
        roundTriptoTextDept = (TextView) findViewById(R.id.roundTriptoTextDept);
        roundTripDateTextDept = (TextView) findViewById(R.id.roundTripDateTextDept);
        roundTripfromTextArr = (TextView) findViewById(R.id.roundTripfromTextArr);
        roundTriptoTextArr = (TextView) findViewById(R.id.roundTriptoTextArr);
        roundTripDateTextArr = (TextView) findViewById(R.id.roundTripDateTextArr);

        roundTripfromTextDept.setText("From: " + intent.getStringExtra("departureLocation"));
        roundTriptoTextDept.setText("To: " + intent.getStringExtra("arrivalLocation"));
        roundTripDateTextDept.setText("Date: " + intent.getStringExtra("departureDate"));

        roundTripfromTextArr.setText("From: " + intent.getStringExtra("arrivalLocation"));
        roundTriptoTextArr.setText("To: " + intent.getStringExtra("departureLocation"));
        roundTripDateTextArr.setText("Date: " + intent.getStringExtra("arrivalDate"));

        availableTicketsDept = (ListView) findViewById(R.id.roundTripAvailableBusesDept);
        availableTicketsArr = (ListView) findViewById(R.id.roundTripAvailableBusesArr);

        arrayOfBuses = database.getBuses(intent.getStringExtra("departureDate"), intent.getStringExtra("departureLocation"), intent.getStringExtra("arrivalLocation"));
        arrayOfBusesArr = database.getBuses(intent.getStringExtra("arrivalDate"), intent.getStringExtra("arrivalLocation"), intent.getStringExtra("departureLocation"));

        final BusAdapter adapter = new BusAdapter(this, arrayOfBuses);
        final BusAdapter adapterArr = new BusAdapter(this, arrayOfBuses);

        availableTicketsDept.setAdapter(adapter);
        availableTicketsArr.setAdapter(adapterArr);

        seatButton = (Button) findViewById(R.id.seatButton);
        seatButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(RoundTripBuyActivity.this, SeatPopUp.class);
                i.putExtra("personNumber", personNumber+"");
                i.putExtra("busTimeDept", arrayOfBuses.get(adapter.selectedPosition).time);
                i.putExtra("busIDDept", arrayOfBuses.get(adapter.selectedPosition).id);
                i.putExtra("busTimeArr", arrayOfBuses.get(adapterArr.selectedPosition).time);
                i.putExtra("busIDArr", arrayOfBusesArr.get(adapterArr.selectedPosition).id);
                i.putExtra("departureLocation", intent.getStringExtra("departureLocation"));
                i.putExtra("arrivalLocation", intent.getStringExtra("arrivalLocation"));
                i.putExtra("departureDate", intent.getStringExtra("departureDate"));
                i.putExtra("arrivalDate", intent.getStringExtra("arrivalDate"));
                i.putExtra("ticketType", intent.getStringExtra("ticketType"));
                i.putExtra("round", "true");
                i.putExtra("clientName", clientName);
                i.putExtra("clientID", intent.getStringExtra("clientID"));

                startActivity(i);
            }
        });

        cancelButton = (Button) findViewById(R.id.oneWayCancelButton);
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(RoundTripBuyActivity.this);
                alertDialogBuilder.setMessage("Selections before chosen will be lost, are you sure?");
                alertDialogBuilder.setPositiveButton("yes",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface arg0, int arg1) {
                                Intent i = new Intent(RoundTripBuyActivity.this, HomeActivity.class);
                                i.putExtra("clientName", clientName);
                                startActivity(i);
                            }
                        });

                alertDialogBuilder.setNegativeButton("No",new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.show();
            }
        });

    }
}
