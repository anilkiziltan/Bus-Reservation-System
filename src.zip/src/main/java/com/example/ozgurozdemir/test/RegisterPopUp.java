package com.example.ozgurozdemir.test;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroupOverlay;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.io.File;

public class RegisterPopUp extends AppCompatActivity {

    private EditText registerUsername, registerPassword, registerName, registerMail, registerPhone;
    private Button registerRegister, registerCancel;
    private Database database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        File myDB = getApplication().getFilesDir();
        final String path = myDB +  "/" + "BusDB";

        database = new Database(path);


        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);

        int width = dm.widthPixels;
        int height = dm.heightPixels;

        getWindow().setLayout((int)(width*.8), (int)(height*.8));

        getSupportActionBar().hide();

        WindowManager.LayoutParams windowManager = getWindow().getAttributes();
        windowManager.dimAmount = 0.75f;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);

        registerUsername = (EditText) findViewById(R.id.registerUsername);
        registerPassword = (EditText) findViewById(R.id.registerPassword);
        registerName = (EditText) findViewById(R.id.registerName);
        registerMail = (EditText) findViewById(R.id.registerMail);
        registerPhone = (EditText) findViewById(R.id.registerTelephone);

        registerRegister = (Button) findViewById(R.id.registerRegister);
        registerCancel = (Button) findViewById(R.id.registerCancel);

        registerCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        registerRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(registerUsername.getText().toString().isEmpty() || registerPassword.getText().toString().isEmpty() || registerName.getText().toString().isEmpty()
                        || registerMail.getText().toString().isEmpty() || registerPhone.getText().toString().isEmpty()){
                        final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(RegisterPopUp.this);
                        alertDialogBuilder.setMessage("Please check your inputs..");

                        alertDialogBuilder.setNegativeButton("OK",new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });

                        AlertDialog alertDialog = alertDialogBuilder.create();
                        alertDialog.show();

                    } else {

                    int register = database.registerDB(registerUsername.getText().toString(), registerPassword.getText().toString(),
                            registerName.getText().toString(), registerMail.getText().toString(), Integer.valueOf(registerPhone.getText().toString()));
                    if (register==1) {
                        final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(RegisterPopUp.this);
                        alertDialogBuilder.setMessage("You registered successfully.");

                        alertDialogBuilder.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                finish();
                            }
                        });

                        AlertDialog alertDialog = alertDialogBuilder.create();
                        alertDialog.show();
                    } else {
                        final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(RegisterPopUp.this);
                        alertDialogBuilder.setMessage("Username is already taken.");

                        alertDialogBuilder.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });

                        AlertDialog alertDialog = alertDialogBuilder.create();
                        alertDialog.show();
                    }

                }


            }
        });

    }



}
