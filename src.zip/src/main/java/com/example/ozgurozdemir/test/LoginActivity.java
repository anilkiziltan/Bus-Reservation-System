package com.example.ozgurozdemir.test;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.File;

public class LoginActivity extends AppCompatActivity {

    private Button login;
    private TextView register;
    private EditText loginUsername, loginPassword;
    private Database database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        File myDB = getApplication().getFilesDir();
        final String path = myDB +  "/" + "BusDB";

        database = new Database(path);

        loginUsername = (EditText) findViewById(R.id.loginUsername);
        loginPassword = (EditText) findViewById(R.id.loginPassword);

        register = (TextView) findViewById(R.id.register);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(LoginActivity.this, RegisterPopUp.class);
                startActivity(i);
            }
        });

        login = (Button) findViewById(R.id.login);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String[] loginInformation = database.loginDB(loginUsername.getText().toString(), loginPassword.getText().toString());
                if(loginUsername.getText().toString().isEmpty() || loginPassword.getText().toString().isEmpty() ||
                        loginInformation[0].equals("") ){
                    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(LoginActivity.this);
                    alertDialogBuilder.setMessage("Please check your inputs..");

                    alertDialogBuilder.setNegativeButton("OK",new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            loginUsername.setText("");
                            loginPassword.setText("");
                        }
                    });

                    AlertDialog alertDialog = alertDialogBuilder.create();
                    alertDialog.show();
                } else {
                    Intent i = new Intent(LoginActivity.this, HomeActivity.class);
                    System.out.println(loginInformation[0] + "--" + loginInformation[1]);
                    i.putExtra("clientID", loginInformation[0]);
                    i.putExtra("clientName", loginInformation[1]);
                    startActivity(i);
                }
            }
        });
        getSupportActionBar().hide();

    }
}
