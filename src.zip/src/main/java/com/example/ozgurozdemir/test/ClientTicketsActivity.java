package com.example.ozgurozdemir.test;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;

public class ClientTicketsActivity extends AppCompatActivity {

    private RelativeLayout noTicketLayout;
    private LinearLayout ticketListLayout;
    private TextView greetingTxt;
    private Button goHomeBtn;
    private ListView clientTicketsList;
    private TicketAdapter adapter;
    private ArrayList<Ticket> tickets = new ArrayList<Ticket>();
    private String clientName, clientID;

    private DrawerLayout nDrawerLayout;
    private ActionBarDrawerToggle mToggle;
    private NavigationView navigation;

    private Database database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client_tickets);
        getSupportActionBar().setTitle("My Tickets");

        File myDB = getApplication().getFilesDir();
        final String path = myDB +  "/" + "BusDB";
        database = new Database(path);

        final Intent intent = getIntent();
        clientID = intent.getStringExtra("clientID");
        clientName = intent.getStringExtra("clientName");

        nDrawerLayout = (DrawerLayout) findViewById(R.id.drawerLayout);
        mToggle = new ActionBarDrawerToggle(this, nDrawerLayout, R.string.open, R.string.close);
        nDrawerLayout.addDrawerListener(mToggle);
        navigation = (NavigationView) findViewById(R.id.navigation);
        mToggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setupDrawerContent(navigation);

        noTicketLayout = (RelativeLayout) findViewById(R.id.noTicketLayout);
        ticketListLayout = (LinearLayout) findViewById(R.id.ticketListLayout);

        greetingTxt = (TextView) findViewById(R.id.greetingTxt);
        greetingTxt.setText("Hi " + intent.getStringExtra("clientName"));

        clientTicketsList = (ListView) findViewById(R.id.clientTicketsList);
        tickets = database.getTickets(intent.getStringExtra("clientID"));
        if(tickets.size()==0){
            noTicketLayout.setVisibility(RelativeLayout.VISIBLE);
            ticketListLayout.setVisibility(LinearLayout.GONE);
        } else {
            noTicketLayout.setVisibility(RelativeLayout.GONE);
            ticketListLayout.setVisibility(LinearLayout.VISIBLE);
        }
        adapter = new TicketAdapter(this, tickets);
        clientTicketsList.setAdapter(adapter);

        goHomeBtn = (Button) findViewById(R.id.goHomeBtn);
        goHomeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(ClientTicketsActivity.this, HomeActivity.class);
                i.putExtra("clientName", clientName);
                i.putExtra("clientID", clientID);
                startActivity(i);
            }
        });

    }

    // toggle the side bar burger
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(mToggle.onOptionsItemSelected(item)){
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    public void selectIterDrawer(MenuItem menuItem){
        switch (menuItem.getItemId()){
            case R.id.nav_buy:
                Intent i = new Intent(ClientTicketsActivity.this, HomeActivity.class);
                i.putExtra("clientName", clientName);
                i.putExtra("clientID", clientID);
                startActivity(i);
                break;
            case R.id.nav_logout:
                Intent i_logut = new Intent(ClientTicketsActivity.this, LoginActivity.class);
                startActivity(i_logut);
                break;
        }
    }
    public void setupDrawerContent(NavigationView navigationView){
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                selectIterDrawer(item);
                return true;
            }
        });
    }
}
