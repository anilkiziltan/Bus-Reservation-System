package com.example.ozgurozdemir.test;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class BuyTicketActivity extends AppCompatActivity {

    private Button buyBuyBtn, buyCancelBtn;
    private EditText buyName, buyCreditCardNumber, buyCVC, buyLastDate;
    private TextView buyPriceTxt;

    private String clientName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buy_ticket_activity);
        setTitle("Buy Bus");

        final Intent intent = getIntent();
        clientName = intent.getStringExtra("clientName");

        buyPriceTxt = (TextView) findViewById(R.id.buyPriceTxt);
        if(intent.getStringExtra("ticketType").equals("Round Trip")){
            buyPriceTxt.setText("Price: " + (Integer.valueOf(intent.getStringExtra("personNumber"))*50*2)+ " TL");
        } else {
            buyPriceTxt.setText("Price: " + (Integer.valueOf(intent.getStringExtra("personNumber"))*50)+ " TL");
        }

        buyName = (EditText) findViewById(R.id.buyName);
        buyCreditCardNumber = (EditText) findViewById(R.id.buyCreditCardNumber);
        buyCVC = (EditText) findViewById(R.id.buyCVC);
        buyLastDate = (EditText) findViewById(R.id.buyLastDate);

        buyBuyBtn = (Button) findViewById(R.id.buyBuyBtn);
        buyCancelBtn = (Button) findViewById(R.id.buyCancelBtn);

        buyCancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(BuyTicketActivity.this);
                alertDialogBuilder.setMessage("Selections before chosen will be lost, are you sure?");
                alertDialogBuilder.setPositiveButton("yes",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface arg0, int arg1) {
                                Intent i = new Intent(BuyTicketActivity.this, HomeActivity.class);
                                i.putExtra("clientName", clientName);
                                i.putExtra("clientID", intent.getStringExtra("clientID"));
                                startActivity(i);
                            }
                        });

                alertDialogBuilder.setNegativeButton("No",new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.show();

            }
        });

        buyBuyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(buyName.getText().toString().isEmpty() || buyCreditCardNumber.getText().toString().isEmpty() || buyCVC.getText().toString().isEmpty() || buyLastDate.getText().toString().isEmpty()){

                    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(BuyTicketActivity.this);
                    alertDialogBuilder.setMessage("Please check your information, all information should be filled...");

                    alertDialogBuilder.setNegativeButton("OK",new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });

                    AlertDialog alertDialog = alertDialogBuilder.create();
                    alertDialog.show();

                } else {
                    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(BuyTicketActivity.this);
                    alertDialogBuilder.setMessage("Are you sure?");
                    alertDialogBuilder.setPositiveButton("yes",
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface arg0, int arg1) {
                                    Intent i = new Intent(BuyTicketActivity.this, SuccessfullyBuyActivity.class);
                                    i.putExtra("personNumber", intent.getStringExtra("personNumber"));
                                    if(intent.getStringExtra("ticketType").equals("Round Trip")){
                                        i.putExtra("busTimeDept", intent.getStringExtra("busTimeDept"));
                                        i.putExtra("busTimeArr", intent.getStringExtra("busTimeArr"));
                                        i.putExtra("busIDDept", intent.getStringExtra("busIDDept"));
                                        i.putExtra("busIDArr", intent.getStringExtra("busIDArr"));
                                    } else {
                                        i.putExtra("busTime", intent.getStringExtra("busTime"));
                                        i.putExtra("busID", intent.getStringExtra("busID"));
                                    }
                                    i.putExtra("departureLocation", intent.getStringExtra("departureLocation"));
                                    i.putExtra("arrivalLocation", intent.getStringExtra("arrivalLocation"));
                                    i.putExtra("departureDate", intent.getStringExtra("departureDate"));
                                    i.putExtra("ticketType", intent.getStringExtra("ticketType"));
                                    if (intent.getStringExtra("ticketType").equals("Round Trip")) {
                                        i.putExtra("seatNumberDept", intent.getStringArrayListExtra("seatNumberDept"));
                                        i.putExtra("seatNumberArr", intent.getStringArrayListExtra("seatNumberArr"));
                                        i.putExtra("seatIDDept", intent.getStringArrayListExtra("seatIDDept"));
                                        i.putExtra("seatIDArr", intent.getStringArrayListExtra("seatIDArr"));
                                    } else {
                                        i.putExtra("seatNumber", intent.getStringArrayListExtra("seatNumber"));
                                        i.putExtra("seatID", intent.getStringArrayListExtra("seatID"));
                                    }
                                    i.putExtra("clientName", clientName);
                                    i.putExtra("clientID", intent.getStringExtra("clientID"));
                                    startActivity(i);
                                }
                            });

                    alertDialogBuilder.setNegativeButton("No",new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });

                    AlertDialog alertDialog = alertDialogBuilder.create();
                    alertDialog.show();

                }
            }
        });


    }
}
