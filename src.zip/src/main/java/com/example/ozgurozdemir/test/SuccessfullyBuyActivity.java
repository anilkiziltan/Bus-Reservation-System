package com.example.ozgurozdemir.test;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.File;

public class SuccessfullyBuyActivity extends AppCompatActivity {

    private Button btnOK;
    private TextView boughtTicketInfo;
    private Database database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_successfully_buy);
        getSupportActionBar().hide();

        final Intent intent = getIntent();

        File myDB = getApplication().getFilesDir();
        final String path = myDB +  "/" + "BusDB";
        database = new Database(path);

        if(intent.getStringExtra("ticketType").equals("One Way")) {
            for(int i = 0; i < intent.getStringArrayListExtra("seatNumber").size(); i++) {
                String seatID = intent.getStringArrayListExtra("seatID").get(i);
                database.buyTicket(seatID, intent.getStringExtra("busID"), intent.getStringExtra("clientID"));
            }
        } else {
            for(int i = 0; i < intent.getStringArrayListExtra("seatNumberDept").size(); i++) {
                String seatID = intent.getStringArrayListExtra("seatIDDept").get(i);
                database.buyTicket(seatID, intent.getStringExtra("busIDDept"), intent.getStringExtra("clientID"));
            }
            for(int i = 0; i < intent.getStringArrayListExtra("seatNumberArr").size(); i++) {
                String seatID = intent.getStringArrayListExtra("seatIDArr").get(i);
                database.buyTicket(seatID, intent.getStringExtra("busIDArr"), intent.getStringExtra("clientID"));
            }
        }

        String ticketInfo = "Bus Information:\n";
        ticketInfo += "Bus Type: " + intent.getStringExtra("ticketType") + "\n";
        ticketInfo += "Passenger: " + intent.getStringExtra("personNumber") + "\n";
        ticketInfo += "From - TO: " + intent.getStringExtra("departureLocation") + "-" +
                intent.getStringExtra("arrivalLocation") + "\n";
        if(intent.getStringExtra("ticketType").equals("One Way")) {
            ticketInfo += "Date: " + intent.getStringExtra("departureDate") + ", " +
                    intent.getStringExtra("busTime") + "\n";
        } else {
            ticketInfo += "Date: " + intent.getStringExtra("departureDate") + ", " +
                    intent.getStringExtra("busTimeDept") + "\n";
        }
        if(intent.getStringExtra("ticketType").equals("One Way")) {
            ticketInfo += "Seat Number: ";
            for(int i = 0; i < intent.getStringArrayListExtra("seatNumber").size()-1; i++) {
                ticketInfo += intent.getStringArrayListExtra("seatNumber").get(i) + ", ";
            }
            ticketInfo += intent.getStringArrayListExtra("seatNumber").get(intent.getStringArrayListExtra("seatNumber").size()-1)+"\n";
        } else {
            ticketInfo += "Seat Number: ";
            for(int i = 0; i < intent.getStringArrayListExtra("seatNumberDept").size()-1; i++) {
                ticketInfo += intent.getStringArrayListExtra("seatNumberDept").get(i) + ", ";
            }
            ticketInfo += intent.getStringArrayListExtra("seatNumberDept").get(intent.getStringArrayListExtra("seatNumberDept").size()-1)+"\n";
        }
        boughtTicketInfo = (TextView) findViewById(R.id.boughtTicketInfo);
        boughtTicketInfo.setText(ticketInfo);

        btnOK = (Button) findViewById(R.id.btnOK);
        btnOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(SuccessfullyBuyActivity.this, HomeActivity.class);
                i.putExtra("clientName", intent.getStringExtra("clientName"));
                i.putExtra("clientID", intent.getStringExtra("clientID"));
                startActivity(i);
            }
        });
    }
}
