package com.example.ozgurozdemir.test;

import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class Database {

    private String path;
    private SQLiteDatabase database;

    public Database(String path){
        this.path = path;
    }

    public void createDB(){
        try{

            database = SQLiteDatabase.openDatabase(path, null, SQLiteDatabase.CREATE_IF_NECESSARY);
            String create = "CREATE TABLE IF NOT EXISTS Passenger(" +
                    "passenger_id text PRIMARY KEY," +
                    "passenger_username text," +
                    "passenger_password text," +
                    "passenger_name text," +
                    "passenger_mail text," +
                    "passenger_phone int);";
            database.execSQL(create);

            create = "CREATE TABLE IF NOT EXISTS Bus(" +
                    "bus_id text PRIMARY KEY," +
                    "bus_departure_time datetime," +
                    "bus_departure_loc text," +
                    "bus_arrival_loc text," +
                    "available_seat int);";
            database.execSQL(create);

            create = "CREATE TABLE IF NOT EXISTS Seat(" +
                    "seat_id text PRIMARY KEY," +
                    "bus_id text," +
                    "state text," +
                    "price int);";
            database.execSQL(create);

            create = "CREATE TABLE IF NOT EXISTS Ticket(" +
                    "ticket_id text PRIMARY KEY," +
                    "seat_id text," +
                    "bus_id text," +
                    "passenger_id text," +
                    "ticket_date datetime," +
                    "ticket_price int);";
            database.execSQL(create);

            database.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void populateDB() {
        try{
            database = SQLiteDatabase.openDatabase(path, null, SQLiteDatabase.CREATE_IF_NECESSARY);
            String dept_location = "";
            String arr_location = "";
            for(int i = 19; i <= 29; i++) {
                for (int j = 10; j <= 24; j += 6) {
                    dept_location = "Istanbul";
                    arr_location = "Ankara";
                    String bus_id = String.format("bus_%s_%s_%d_%d", dept_location, arr_location, i, j);
                    for (int s = 1; s <= 29; s++) {
                        String seat_id = String.format("seat_%d_%s", s, bus_id);
                        String create = "INSERT INTO Seat VALUES('" +
                                seat_id + "', '" + bus_id + "', " +
                                "'available', 50);";
                        database.execSQL(create);
                    }
                    String create = "INSERT INTO Bus VALUES('" +
                            bus_id + "', '2017-12-" + i + " " + j + ":00:00','" +
                            dept_location + "','" + arr_location + "', 29)";
                    database.execSQL(create);
                }
                for (int j = 10; j <= 24; j += 6) {
                    dept_location = "Istanbul";
                    arr_location = "Izmir";
                    String bus_id = String.format("bus_%s_%s_%d_%d", dept_location, arr_location, i, j);
                    for (int s = 1; s <= 29; s++) {
                        String seat_id = String.format("seat_%d_%s", s, bus_id);
                        String create = "INSERT INTO Seat VALUES('" +
                                seat_id + "', '" + bus_id + "', " +
                                "'available', 50);";
                        database.execSQL(create);
                    }
                    String create = "INSERT INTO Bus VALUES('" +
                            bus_id + "', '2017-12-" + i + " " + j + ":00:00','" +
                            dept_location + "','" + arr_location + "', 29)";
                    database.execSQL(create);
                }
                for (int j = 10; j <= 24; j += 6) {
                    dept_location = "Ankara";
                    arr_location = "Istanbul";
                    String bus_id = String.format("bus_%s_%s_%d_%d", dept_location, arr_location, i, j);
                    for (int s = 1; s <= 29; s++) {
                        String seat_id = String.format("seat_%d_%s", s, bus_id);
                        String create = "INSERT INTO Seat VALUES('" +
                                seat_id + "', '" + bus_id + "', " +
                                "'available', 50);";
                        database.execSQL(create);
                    }
                    String create = "INSERT INTO Bus VALUES('" +
                            bus_id + "', '2017-12-" + i + " " + j + ":00:00','" +
                            dept_location + "','" + arr_location + "', 29)";
                    database.execSQL(create);
                }
                for (int j = 10; j <= 24; j += 6) {
                    dept_location = "Ankara";
                    arr_location = "Izmir";
                    String bus_id = String.format("bus_%s_%s_%d_%d", dept_location, arr_location, i, j);
                    for (int s = 1; s <= 29; s++) {
                        String seat_id = String.format("seat_%d_%s", s, bus_id);
                        String create = "INSERT INTO Seat VALUES('" +
                                seat_id + "', '" + bus_id + "', " +
                                "'available', 50);";
                        database.execSQL(create);
                    }
                    String create = "INSERT INTO Bus VALUES('" +
                            bus_id + "', '2017-12-" + i + " " + j + ":00:00','" +
                            dept_location + "','" + arr_location + "', 29)";
                    database.execSQL(create);
                }
                for (int j = 10; j <= 24; j += 6) {
                    dept_location = "Izmir";
                    arr_location = "Istanbul";
                    String bus_id = String.format("bus_%s_%s_%d_%d", dept_location, arr_location, i, j);
                    for (int s = 1; s <= 29; s++) {
                        String seat_id = String.format("seat_%d_%s", s, bus_id);
                        String create = "INSERT INTO Seat VALUES('" +
                                seat_id + "', '" + bus_id + "', " +
                                "'available', 50);";
                        database.execSQL(create);
                    }
                    String create = "INSERT INTO Bus VALUES('" +
                            bus_id + "', '2017-12-" + i + " " + j + ":00:00','" +
                            dept_location + "','" + arr_location + "', 29)";
                    database.execSQL(create);
                }
                for (int j = 10; j <= 24; j += 6) {
                    dept_location = "Izmir";
                    arr_location = "Ankara";
                    String bus_id = String.format("bus_%s_%s_%d_%d", dept_location, arr_location, i, j);
                    for (int s = 1; s <= 29; s++) {
                        String seat_id = String.format("seat_%d_%s", s, bus_id);
                        String create = "INSERT INTO Seat VALUES('" +
                                seat_id + "', '" + bus_id + "', " +
                                "'available', 50);";
                        database.execSQL(create);
                    }
                    String create = "INSERT INTO Bus VALUES('" +
                            bus_id + "', '2017-12-" + i + " " + j + ":00:00','" +
                            dept_location + "','" + arr_location + "', 29)";
                    database.execSQL(create);
                }
            }
            database.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public int registerDB(String username, String password, String name, String mail, int phone){

        try{

            database = SQLiteDatabase.openDatabase(path, null, SQLiteDatabase.CREATE_IF_NECESSARY);
            String id = "passenger_" + username;
            String sql = "select * from Passenger";
            Cursor c1 = database.rawQuery(sql, null);
            c1.moveToPosition(-1);
            while ( c1.moveToNext() ){
                String _ = c1.getString(0);
                if(_.equals(id)){
                    return -1;
                }
            }

            String register = "INSERT INTO Passenger VALUES('" +
                    id + "','" + username +
                    "','" + password + "','" + name + "','" +
                    mail + "'," + phone + ");";
            database.execSQL(register);

            database.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 1;
    }

    public String[] loginDB(String username, String password){

        String[] loginInformation = {"",""};

        try{
            database = SQLiteDatabase.openDatabase(path, null, SQLiteDatabase.CREATE_IF_NECESSARY);
            String sql = "select * from Passenger";
            Cursor c1 = database.rawQuery(sql, null);
            c1.moveToPosition(-1);
            while ( c1.moveToNext() ){
                String u = c1.getString(1);
                String p = c1.getString(2);
                if(username.equals(u) && password.equals(p)){
                    loginInformation[0] = c1.getString(0);
                    loginInformation[1] = c1.getString(3);
                    return loginInformation;
                }
            }

            database.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return loginInformation;

    }

    public String getUpcomingTicket(String userID){
        try{
            database = SQLiteDatabase.openDatabase(path, null, SQLiteDatabase.CREATE_IF_NECESSARY);
            String sql = "SELECT * FROM Ticket WHERE passenger_id='" +
                    userID + "' ORDER BY ticket_date DESC;";
            Cursor c1 = database.rawQuery(sql, null);
            if(c1.getCount()!=0){
                c1.moveToPosition(0);
                String[] information = c1.getString(0).split("_");
                return information[7] + ":00, " + information[6] + "/12/2017, " + information[4] + "-" + information[5];
            }
            database.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "";
    }

    public ArrayList<Ticket> getTickets(String userID){
        ArrayList<Ticket> result = new ArrayList<Ticket>();
        try{
            database = SQLiteDatabase.openDatabase(path, null, SQLiteDatabase.CREATE_IF_NECESSARY);
            String sql = "SELECT * FROM Ticket WHERE passenger_id='" +
                    userID + "' ORDER BY ticket_date DESC;";
            Cursor c1 = database.rawQuery(sql, null);
            c1.moveToPosition(-1);
            while (c1.moveToNext()){
                String[] information = c1.getString(0).split("_");
                String seat = c1.getString(1).split("_")[1];
                result.add(new Ticket(c1.getString(0), information[7]+":00", information[6] + "/12/2017",
                       information[4], information[5], Integer.valueOf(seat)));
            }
            database.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    public ArrayList<Bus> getBuses(String date, String departure, String arrival){
        ArrayList<Bus> result = new ArrayList<Bus>();
        try{
            database = SQLiteDatabase.openDatabase(path, null, SQLiteDatabase.CREATE_IF_NECESSARY);
            String [] day = date.split("/");
            String sql = "SELECT * FROM Bus WHERE " +
                    "bus_departure_time between '2017-12-" +
                    day[0] + " 0:00:00' and '2017-12-" + (Integer.valueOf(day[0]) + 1) + " 0:00:00' AND " +
                    "bus_departure_loc='" + departure + "' AND bus_arrival_loc='" +
                    arrival + "' ORDER BY bus_departure_time ASC;";
            Cursor c1 = database.rawQuery(sql, null);
            c1.moveToPosition(-1);

            while ( c1.moveToNext() ){
                String [] _ = c1.getString(1).split(" ");
                String hour = _[1].split(":")[0];
                result.add(new Bus(c1.getString(0),hour+":00", c1.getInt(4)));
            }
            database.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;

    }

    public String[] getSeats(String busID){
        String result[] = new String[30];
        try{
            database = SQLiteDatabase.openDatabase(path, null, SQLiteDatabase.CREATE_IF_NECESSARY);
            String sql = "SELECT * FROM Seat WHERE bus_id='" + busID + "';";
            Cursor c1 = database.rawQuery(sql, null);
            c1.moveToPosition(-1);
            int i = 0;
            while ( c1.moveToNext() ){
               result[i] = c1.getString(2);
               i++;
               if(i==29) {
                   result[i] = c1.getString(2);
               }
            }
            database.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    public void buyTicket(String seatID, String busID, String passengerID){
        try{
            database = SQLiteDatabase.openDatabase(path, null, SQLiteDatabase.CREATE_IF_NECESSARY);
            String ticketID = "ticket_" + seatID + "_" + passengerID;
            String date = "2017-12-" + busID.split("_")[3] + " " + busID.split("_")[4] + ":00:00";
            String sql = "INSERT INTO Ticket VALUES('" +
                    ticketID + "','" + seatID + "','" + busID + "','" + passengerID + "','" + date +
                    "', 50);";
            database.execSQL(sql);

            sql = "UPDATE Bus SET available_seat=available_seat-1 WHERE bus_id='" + busID + "';";
            database.execSQL(sql);

            sql = "UPDATE Seat SET state='unavailable' WHERE seat_id='" + seatID + "';";
            database.execSQL(sql);

            database.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }


    }


}
