package com.example.ozgurozdemir.test;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.NumberPicker;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.util.Calendar;

public class HomeActivity extends AppCompatActivity {

    private DrawerLayout nDrawerLayout;
    private ActionBarDrawerToggle mToggle;
    private NavigationView navigation;

    private Button btnOneWay, btnTwoWay,btnLogout, oneWayfromButton, oneWaytoButton, oneWayPersonButton
            ,oneWayDepartureDateButton, oneWayListTicketButton, roundTripfromButton, roundTriptoButton, roundTripPersonButton
            ,roundTripDeptDateButton, roundTripArrDateButton, roundTripListTicketButton;
    private CharSequence[] locations = {"Istanbul", "Ankara", "Izmir"};

    private View oneWayLayout, twoWayLayout;

    private String clientName, ticketType = "One Way", clientID;

    private TextView greetingText, ticketInfoTxt;

    private Database database;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        getSupportActionBar().setTitle("Home");

        File myDB = getApplication().getFilesDir();
        final String path = myDB +  "/" + "BusDB";
        database = new Database(path);

        final Intent intent = getIntent();
        clientName = intent.getStringExtra("clientName");
        clientID = intent.getStringExtra("clientID");

        String upcoming = database.getUpcomingTicket(intent.getStringExtra("clientID"));
        ticketInfoTxt = (TextView) findViewById(R.id.ticketInfoTxt);
        if(!upcoming.equals(""))
            ticketInfoTxt.setText(upcoming);

        greetingText = (TextView) findViewById(R.id.greetingTxt);
        greetingText.setText("Welcome " + clientName);

        btnOneWay = (Button) findViewById(R.id.btnOneWay);
        btnTwoWay = (Button) findViewById(R.id.btnTwoWay);
        oneWayLayout = (View) findViewById(R.id.oneWayLayout);
        twoWayLayout = (View) findViewById(R.id.twoWayLayout);

        nDrawerLayout = (DrawerLayout) findViewById(R.id.drawerLayout);
        mToggle = new ActionBarDrawerToggle(this, nDrawerLayout, R.string.open, R.string.close);

        nDrawerLayout.addDrawerListener(mToggle);
        mToggle.syncState();

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        navigation = (NavigationView) findViewById(R.id.navigation);
        mToggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setupDrawerContent(navigation);

        btnLogout = (Button) findViewById(R.id.btnLogout);

        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(HomeActivity.this, LoginActivity.class);
                startActivity(i);
            }
        });

        // Changing the one way or round trip layout

        btnOneWay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                    btnOneWay.setBackground(getResources().getDrawable(R.drawable.oneway_button_active));
                }
                btnOneWay.setTextColor(getResources().getColor(R.color.background));
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                    btnTwoWay.setBackground(getResources().getDrawable(R.drawable.twoway_button_inactive));
                }
                btnTwoWay.setTextColor(getResources().getColor(R.color.actionBar));
                twoWayLayout.setVisibility(View.GONE);
                oneWayLayout.setVisibility(View.VISIBLE);
                ticketType = "One Way";
            }
        });

        btnTwoWay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                    btnOneWay.setBackground(getResources().getDrawable(R.drawable.oneway_button_inactive));
                }
                btnOneWay.setTextColor(getResources().getColor(R.color.actionBar));
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                    btnTwoWay.setBackground(getResources().getDrawable(R.drawable.twoway_button_active));
                }
                btnTwoWay.setTextColor(getResources().getColor(R.color.background));
                twoWayLayout.setVisibility(View.VISIBLE);
                oneWayLayout.setVisibility(View.GONE);
                ticketType = "Round Trip";
            }
        });

        // input buttons of onewaylayout
        // fromButton on oneway layout
        oneWayfromButton = (Button) findViewById(R.id.oneWayfromButton);
        oneWayfromButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(HomeActivity.this);
                builder.setTitle("Select your departure location:");
                builder.setItems(locations, new DialogInterface.OnClickListener(){
                        public void onClick(DialogInterface dialog, int item) {
                            // Do something with the selection
                            oneWayfromButton.setText(locations[item]);
                    }
                });
                AlertDialog alert = builder.create();
                alert.show();

            }
        });

        // toButton on oneway layout
        oneWaytoButton = (Button) findViewById(R.id.oneWaytoButton);
        oneWaytoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(HomeActivity.this);
                builder.setTitle("Select your departure location:");
                builder.setItems(locations, new DialogInterface.OnClickListener(){
                    public void onClick(DialogInterface dialog, int item) {
                        // Do something with the selection
                        oneWaytoButton.setText(locations[item]);
                    }
                });
                AlertDialog alert = builder.create();
                alert.show();

            }
        });

        // person button on onewaylayout
        oneWayPersonButton = (Button)findViewById(R.id.oneWayPersonButton);
        oneWayPersonButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Dialog d = new Dialog(HomeActivity.this);
                d.setTitle("NumberPicker");
                d.setContentView(R.layout.dialog);
                Button b1 = (Button) d.findViewById(R.id.setButton);
                Button b2 = (Button) d.findViewById(R.id.cancelButton);
                final NumberPicker np = (NumberPicker) d.findViewById(R.id.numberPicker);
                np.setMaxValue(20); // max value 20
                np.setMinValue(1);   // min value 1
                np.setWrapSelectorWheel(false);
                //np.setOnValueChangedListener(this);
                b1.setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View v) {
                        oneWayPersonButton.setText(String.valueOf(np.getValue())); //set the value to textview
                        d.dismiss();
                    }
                });
                b2.setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View v) {
                        d.dismiss(); // dismiss the dialog
                    }
                });
                d.show();

            }
        });

        // departure date on onewaylayout
        oneWayDepartureDateButton = (Button) findViewById(R.id.oneWayDepartureDateButton);
        final Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH) + 1;
        int day = c.get(Calendar.DAY_OF_MONTH);
        oneWayDepartureDateButton.setText(day +"/"+month+"/"+year);
        oneWayDepartureDateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Calendar c = Calendar.getInstance();
                int year = c.get(Calendar.YEAR);
                int month = c.get(Calendar.MONTH);
                int day = c.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        HomeActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                        oneWayDepartureDateButton.setText(i2 +"/"+(i1+1)+"/"+i);
                    }
                }, year, month, day);
                datePickerDialog.show();
            }
        });

        // list tickets on onewaylayout
        oneWayListTicketButton = (Button) findViewById(R.id.oneWayListTicketButton);
        oneWayListTicketButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(oneWayfromButton.getText().toString().equals(oneWaytoButton.getText().toString())){

                    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(HomeActivity.this);
                    alertDialogBuilder.setMessage("Please check your destinations...");

                    alertDialogBuilder.setNegativeButton("OK",new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });

                    AlertDialog alertDialog = alertDialogBuilder.create();
                    alertDialog.show();

                } else {
                    Intent i = new Intent(HomeActivity.this, OneWayBuyActivity.class);
                    i.putExtra("personNumber", String.valueOf(oneWayPersonButton.getText()));
                    i.putExtra("departureLocation", String.valueOf(oneWayfromButton.getText()));
                    i.putExtra("arrivalLocation", String.valueOf(oneWaytoButton.getText()));
                    i.putExtra("departureDate", String.valueOf(oneWayDepartureDateButton.getText()));
                    i.putExtra("ticketType", ticketType);
                    i.putExtra("clientName", clientName);
                    i.putExtra("clientID", intent.getStringExtra("clientID"));
                    startActivity(i);
                }
            }
        });

        // Round Trip

        roundTripfromButton = (Button) findViewById(R.id.roundTripfromButton);
        roundTripfromButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(HomeActivity.this);
                builder.setTitle("Select your departure location:");
                builder.setItems(locations, new DialogInterface.OnClickListener(){
                    public void onClick(DialogInterface dialog, int item) {
                        // Do something with the selection
                        roundTripfromButton.setText(locations[item]);
                    }
                });
                AlertDialog alert = builder.create();
                alert.show();

            }
        });

        // toButton on oneway layout
        roundTriptoButton = (Button) findViewById(R.id.roundTriptoButton);
        roundTriptoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(HomeActivity.this);
                builder.setTitle("Select your departure location:");
                builder.setItems(locations, new DialogInterface.OnClickListener(){
                    public void onClick(DialogInterface dialog, int item) {
                        // Do something with the selection
                        roundTriptoButton.setText(locations[item]);
                    }
                });
                AlertDialog alert = builder.create();
                alert.show();

            }
        });

        // person button on onewaylayout
        roundTripPersonButton = (Button)findViewById(R.id.roundTripPersonButton);
        roundTripPersonButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Dialog d = new Dialog(HomeActivity.this);
                d.setTitle("NumberPicker");
                d.setContentView(R.layout.dialog);
                Button b1 = (Button) d.findViewById(R.id.setButton);
                Button b2 = (Button) d.findViewById(R.id.cancelButton);
                final NumberPicker np = (NumberPicker) d.findViewById(R.id.numberPicker);
                np.setMaxValue(20); // max value 20
                np.setMinValue(1);   // min value 1
                np.setWrapSelectorWheel(false);
                //np.setOnValueChangedListener(this);
                b1.setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View v) {
                        roundTripPersonButton.setText(String.valueOf(np.getValue())); //set the value to textview
                        d.dismiss();
                    }
                });
                b2.setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View v) {
                        d.dismiss(); // dismiss the dialog
                    }
                });
                d.show();

            }
        });

        // departure date on onewaylayout
        roundTripDeptDateButton = (Button) findViewById(R.id.roundTripDeptDateButton);
        year = c.get(Calendar.YEAR);
        month = c.get(Calendar.MONTH) + 1;
        day = c.get(Calendar.DAY_OF_MONTH);
        roundTripDeptDateButton.setText(day +"/"+month+"/"+year);
        roundTripDeptDateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Calendar c = Calendar.getInstance();
                int year = c.get(Calendar.YEAR);
                int month = c.get(Calendar.MONTH) ;
                int day = c.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        HomeActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                        roundTripDeptDateButton.setText(i2 +"/"+(i1+1)+"/"+i);
                    }
                }, year, month, day);
                datePickerDialog.show();
            }
        });

        roundTripArrDateButton = (Button) findViewById(R.id.roundTripArrDateButton);
        year = c.get(Calendar.YEAR);
        month = c.get(Calendar.MONTH)+1;
        day = c.get(Calendar.DAY_OF_MONTH);
        roundTripArrDateButton.setText(day +"/"+month+"/"+year);
        roundTripArrDateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Calendar c = Calendar.getInstance();
                int year = c.get(Calendar.YEAR);
                int month = c.get(Calendar.MONTH);
                int day = c.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        HomeActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                        roundTripArrDateButton.setText(i2 +"/"+(i1+1)+"/"+i);
                    }
                }, year, month, day);
                datePickerDialog.show();
            }
        });


        // list tickets on onewaylayout
        roundTripListTicketButton = (Button) findViewById(R.id.roundTripListTicketButton);
        roundTripListTicketButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean roundDate = Integer.valueOf(roundTripDeptDateButton.getText().toString().split("/")[0]) >
                        Integer.valueOf(roundTripArrDateButton.getText().toString().split("/")[0]);
                if(roundTripfromButton.getText().toString().equals(roundTriptoButton.getText().toString()) ||
                        roundTripDeptDateButton.getText().toString().equals(roundTripArrDateButton.getText().toString()) || roundDate){

                    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(HomeActivity.this);
                    alertDialogBuilder.setMessage("Please check your destinations and dates...");

                    alertDialogBuilder.setNegativeButton("OK",new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });

                    AlertDialog alertDialog = alertDialogBuilder.create();
                    alertDialog.show();

                } else {
                    Intent i = new Intent(HomeActivity.this, RoundTripBuyActivity.class);
                    i.putExtra("personNumber", String.valueOf(roundTripPersonButton.getText()));
                    i.putExtra("departureLocation", String.valueOf(roundTripfromButton.getText()));
                    i.putExtra("arrivalLocation", String.valueOf(roundTriptoButton.getText()));
                    i.putExtra("departureDate", String.valueOf(roundTripDeptDateButton.getText()));
                    i.putExtra("arrivalDate", String.valueOf(roundTripArrDateButton.getText()));
                    i.putExtra("ticketType", ticketType);
                    i.putExtra("clientName", clientName);
                    i.putExtra("clientID", intent.getStringExtra("clientID"));
                    startActivity(i);
                }
            }
        });



    }
    // toggle the side bar burger
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(mToggle.onOptionsItemSelected(item)){
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void selectIterDrawer(MenuItem menuItem){
        switch (menuItem.getItemId()){
            case R.id.nav_tickets:
                Intent i = new Intent(HomeActivity.this, ClientTicketsActivity.class);
                i.putExtra("clientName", clientName);
                i.putExtra("clientID", clientID);
                startActivity(i);
                break;
            case R.id.nav_logout:
                Intent i_logut = new Intent(HomeActivity.this, LoginActivity.class);
                startActivity(i_logut);
                break;
        }

    }
    public void setupDrawerContent(NavigationView navigationView){
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                selectIterDrawer(item);
                return true;
            }
        });
    }

}
