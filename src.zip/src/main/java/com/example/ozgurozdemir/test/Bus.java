package com.example.ozgurozdemir.test;


public class Bus {
    public String time;
    public String id;
    public int freeSeat;
    public Bus(String id, String time, int freeSeat){
        this.id = id;
        this.time = time;
        this.freeSeat = freeSeat;
    }
}
