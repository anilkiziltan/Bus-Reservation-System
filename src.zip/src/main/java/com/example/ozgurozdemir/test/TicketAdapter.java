package com.example.ozgurozdemir.test;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.RadioButton;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class TicketAdapter extends ArrayAdapter<Ticket> {

    public TicketAdapter(Context context, ArrayList<Ticket> tickets) {
        super(context, 0, tickets);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Get the data item for this position
        Ticket ticket = getItem(position);
        // Check if an existing view is being reused, otherwise inflate the view
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_ticket, parent, false);
        }
        // Lookup view for data population
        RadioButton radioButton = (RadioButton) convertView.findViewById(R.id.radioButton);
        TextView timeText = (TextView) convertView.findViewById(R.id.ticketTimeTxt);
        TextView dateTxt = (TextView) convertView.findViewById(R.id.ticketDateTxt);
        TextView locationTxt = (TextView) convertView.findViewById(R.id.ticketLocationTxt);
        TextView seatTxt = (TextView) convertView.findViewById(R.id.ticketSeatTxt);
        // Populate the data into the template view using the data object
        timeText.setText(ticket.time);
        dateTxt.setText(ticket.date);
        locationTxt.setText(ticket.location);
        seatTxt.setText("Seat No: " + ticket.seat);

        // Return the completed view to render on screen
        return convertView;
    }
}