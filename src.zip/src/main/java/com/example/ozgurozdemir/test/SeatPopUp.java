package com.example.ozgurozdemir.test;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;

public class SeatPopUp extends AppCompatActivity {

    private Button seatBuyButton, seatCancelButton;
    private TextView seatPersonNumberTxt, seatTimeInfo, seatLocationInfo, seatDateInfo;
    private TableLayout seatTable;
    private int selected =  Color.rgb(212,64,64);
    private int available = Color.rgb(92,104,124);
    private int unavailable = Color.rgb(33,37,43);
    private int personNumber;
    private String seatNumber;
    private Database database;

    private ArrayList<String> selectedSeats = new ArrayList<String>();
    private ArrayList<String> selectedSeatsID = new ArrayList<String>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seat);

        File myDB = getApplication().getFilesDir();
        final String path = myDB +  "/" + "BusDB";
        database = new Database(path);

        final Intent intent = getIntent();
        final String selectedPosition = intent.getStringExtra("selectedBus");
        String personNumberString = intent.getStringExtra("personNumber");
        personNumber = Integer.parseInt(personNumberString+"");

        seatPersonNumberTxt = (TextView) findViewById(R.id.seatPersonNumberTxt);
        seatPersonNumberTxt.setText(String.valueOf(personNumber));

        seatTimeInfo = (TextView) findViewById(R.id.seatTimeInfo);
        seatLocationInfo = (TextView) findViewById(R.id.seatLocationInfo);
        seatDateInfo = (TextView) findViewById(R.id.seatDateInfo);

        if(intent.getStringExtra("ticketType").equals("One Way")) {
            seatTimeInfo.setText(intent.getStringExtra("busTime"));
            seatLocationInfo.setText(intent.getStringExtra("departureLocation") + "-" + intent.getStringExtra("arrivalLocation"));
            seatDateInfo.setText(intent.getStringExtra("departureDate"));
        } else {
            if(intent.getStringExtra("round").equals("true")){
                seatTimeInfo.setText(intent.getStringExtra("busTimeDept"));
                seatLocationInfo.setText(intent.getStringExtra("departureLocation") + "-" + intent.getStringExtra("arrivalLocation"));
                seatDateInfo.setText(intent.getStringExtra("departureDate"));
            } else {
                seatTimeInfo.setText(intent.getStringExtra("busTimeArr"));
                seatLocationInfo.setText(intent.getStringExtra("arrivalLocation") + "-" + intent.getStringExtra("departureLocation"));
                seatDateInfo.setText(intent.getStringExtra("arrivalDate"));
            }
        }

        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);

        int width = dm.widthPixels;
        int height = dm.heightPixels;

        getWindow().setLayout((int)(width*.8), (int)(height*.7));

        getSupportActionBar().hide();

        WindowManager.LayoutParams windowManager = getWindow().getAttributes();
        windowManager.dimAmount = 0.75f;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);

        seatCancelButton = (Button) findViewById(R.id.seatCancelButton);
        seatCancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        seatBuyButton = (Button) findViewById(R.id.seatBuyButton);

        if(intent.getStringExtra("ticketType").equals("Round Trip") && intent.getStringExtra("round").equals("true")){
            seatBuyButton.setText("Next");
            seatBuyButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(personNumber==0) {
                        Intent i = new Intent(SeatPopUp.this, SeatPopUp.class);
                        i.putExtra("personNumber", intent.getStringExtra("personNumber"));
                        i.putExtra("busTimeDept", intent.getStringExtra("busTimeDept"));
                        i.putExtra("busTimeArr", intent.getStringExtra("busTimeArr"));
                        i.putExtra("busIDDept", intent.getStringExtra("busIDDept"));
                        i.putExtra("busIDArr", intent.getStringExtra("busIDArr"));
                        i.putExtra("departureLocation", intent.getStringExtra("departureLocation"));
                        i.putExtra("arrivalLocation", intent.getStringExtra("arrivalLocation"));
                        i.putExtra("departureDate", intent.getStringExtra("departureDate"));
                        i.putExtra("arrivalDate", intent.getStringExtra("arrivalDate"));
                        i.putExtra("seatNumberDept", selectedSeats);
                        for(int j = 0; j < selectedSeats.size(); j++){
                            String seatID = "seat_" + selectedSeats.get(j) + "_" + intent.getStringExtra("busIDDept");
                            selectedSeatsID.add(seatID);
                        }
                        i.putExtra("seatIDDept", selectedSeatsID);
                        i.putExtra("ticketType", intent.getStringExtra("ticketType"));
                        i.putExtra("clientName", intent.getStringExtra("clientName"));
                        i.putExtra("clientID", intent.getStringExtra("clientID"));
                        i.putExtra("round", "false");
                        startActivity(i);
                    }
                }
            });


        } else {

            seatBuyButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (personNumber == 0) {
                        Intent i = new Intent(SeatPopUp.this, BuyTicketActivity.class);
                        i.putExtra("personNumber", intent.getStringExtra("personNumber"));
                        if(intent.getStringExtra("ticketType").equals("Round Trip")){
                            i.putExtra("busTimeDept", intent.getStringExtra("busTimeDept"));
                            i.putExtra("busTimeArr", intent.getStringExtra("busTimeArr"));
                            i.putExtra("busIDDept", intent.getStringExtra("busIDDept"));
                            i.putExtra("busIDArr", intent.getStringExtra("busIDArr"));
                        } else {
                            i.putExtra("busTime", intent.getStringExtra("busTime"));
                            i.putExtra("busID", intent.getStringExtra("busID"));
                        }
                        i.putExtra("departureLocation", intent.getStringExtra("departureLocation"));
                        i.putExtra("arrivalLocation", intent.getStringExtra("arrivalLocation"));
                        i.putExtra("departureDate", intent.getStringExtra("departureDate"));

                        if (intent.getStringExtra("ticketType").equals("Round Trip")) {
                            for(int j = 0; j < selectedSeats.size(); j++){
                                String seatID = "seat_" + selectedSeats.get(j) + "_" + intent.getStringExtra("busIDArr");
                                selectedSeatsID.add(seatID);
                            }
                            i.putExtra("arrivalDate", intent.getStringExtra("arrivalDate"));
                            i.putExtra("seatNumberDept", intent.getStringArrayListExtra("seatNumberDept"));
                            i.putExtra("seatNumberArr", selectedSeats);
                            i.putExtra("seatIDDept", intent.getStringArrayListExtra("seatIDDept"));
                            i.putExtra("seatIDArr", selectedSeatsID);
                        } else {
                            for(int j = 0; j < selectedSeats.size(); j++){
                                String seatID = "seat_" + selectedSeats.get(j) + "_" + intent.getStringExtra("busID");
                                selectedSeatsID.add(seatID);
                            }
                            i.putExtra("seatNumber", selectedSeats);
                            i.putExtra("seatID", selectedSeatsID);
                        }
                        i.putExtra("ticketType", intent.getStringExtra("ticketType"));
                        i.putExtra("clientName", intent.getStringExtra("clientName"));
                        i.putExtra("clientID", intent.getStringExtra("clientID"));

                        startActivity(i);
                    }
                }
            });
        }

        seatTable = (TableLayout)findViewById(R.id.seatTable);

        String[] availability = new String[30];
        if(intent.getStringExtra("ticketType").equals("Round Trip")){
            if (intent.getStringExtra("round").equals("false")){
                availability = database.getSeats(intent.getStringExtra("busIDDept"));
            } else {
                availability = database.getSeats(intent.getStringExtra("busIDArr"));
            }
        } else {
            availability = database.getSeats(intent.getStringExtra("busID"));
        }

        for(int i = 0; i < 6; i++) {
            TableRow row = new TableRow(this);
            row.setHorizontalGravity(Gravity.CENTER);
            for (int l = i*4; l < i*4+2; l++) {
                final Button btn = new Button(this);
                btn.setLayoutParams(new TableRow.LayoutParams(100, 100));
                btn.setBackgroundColor(available);
                btn.setText(l + 1 + "");
                btn.setTag(availability[l]);

                btn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(personNumber!=0) {
                            if (btn.getTag().equals("available")) {
                                btn.setBackgroundColor(selected);
                                btn.setTextColor(Color.WHITE);
                                btn.setTag("selected");
                                personNumber--;
                                seatNumber = btn.getText().toString();
                                selectedSeats.add(seatNumber);
                                seatPersonNumberTxt.setText(personNumber + "");
                            } else {
                                btn.setBackgroundColor(available);
                                btn.setTextColor(Color.BLACK);
                                btn.setTag("available");
                                personNumber++;
                                selectedSeats.remove(btn.getText().toString());
                                seatPersonNumberTxt.setText(personNumber + "");
                            }
                        }
                        else {
                            if(btn.getTag().equals("selected")) {
                                btn.setBackgroundColor(available);
                                btn.setTextColor(Color.BLACK);
                                btn.setTag("available");
                                personNumber++;
                                selectedSeats.remove(btn.getText().toString());
                                seatPersonNumberTxt.setText(personNumber + "");
                            }
                        }

                    }
                });
                if(availability[l].equals("unavailable")){
                    btn.setBackgroundColor(unavailable);
                    btn.setTextColor(Color.LTGRAY);
                    btn.setTag("unavailable");
                    btn.setClickable(false);
                }
                row.addView(btn);
            }
            Button divider = new Button(this);
            divider.setLayoutParams(new TableRow.LayoutParams(100, 100));
            divider.setBackgroundColor(Color.rgb(253,239,239));
            divider.setClickable(false);
            divider.setWidth(20);
            row.addView(divider);
            for (int r = i*4+2; r < i*4+4; r++) {
                final Button btn = new Button(this);
                btn.setLayoutParams(new TableRow.LayoutParams(100, 100));
                btn.setBackgroundColor(available);
                btn.setText(r + 1 + "");
                btn.setTag(availability[r]);

                btn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(personNumber!=0) {
                            if (btn.getTag().equals("available")) {
                                btn.setBackgroundColor(selected);
                                btn.setTextColor(Color.WHITE);
                                btn.setTag("selected");
                                personNumber--;
                                seatNumber = btn.getText().toString();
                                selectedSeats.add(seatNumber);
                                seatPersonNumberTxt.setText(personNumber + "");
                            } else {
                                btn.setBackgroundColor(available);
                                btn.setTextColor(Color.BLACK);
                                btn.setTag("available");
                                personNumber++;
                                selectedSeats.remove(btn.getText().toString());
                                seatPersonNumberTxt.setText(personNumber + "");
                            }
                        }
                        else {
                            if(btn.getTag().equals("selected")) {
                                btn.setBackgroundColor(available);
                                btn.setTextColor(Color.BLACK);
                                btn.setTag("available");
                                personNumber++;
                                selectedSeats.remove(btn.getText().toString());
                                seatPersonNumberTxt.setText(personNumber + "");
                            }
                        }

                    }
                });
                if(availability[r].equals("unavailable")){
                    btn.setBackgroundColor(unavailable);
                    btn.setTextColor(Color.BLACK);
                    btn.setTag("unavailable");
                    btn.setClickable(false);
                }
                row.addView(btn);
            }
            seatTable.addView(row);
        }
        TableRow row = new TableRow(this);
        row.setHorizontalGravity(Gravity.CENTER);
        for (int j = 25; j < 30; j++) {
            final Button btn = new Button(this);
            btn.setLayoutParams(new TableRow.LayoutParams(100, 100));
            btn.setBackgroundColor(available);
            btn.setText(j + "");
            btn.setTag(availability[j]);

            btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(personNumber!=0) {
                        if (btn.getTag().equals("available")) {
                            btn.setBackgroundColor(selected);
                            btn.setTextColor(Color.WHITE);
                            btn.setTag("selected");
                            personNumber--;
                            seatNumber = btn.getText().toString();
                            selectedSeats.add(seatNumber);
                            seatPersonNumberTxt.setText(personNumber + "");
                        } else {
                            btn.setBackgroundColor(available);
                            btn.setTextColor(Color.BLACK);
                            btn.setTag("available");
                            personNumber++;
                            selectedSeats.remove(btn.getText().toString());
                            seatPersonNumberTxt.setText(personNumber + "");
                        }
                    }
                    else {
                        if(btn.getTag().equals("selected")) {
                            btn.setBackgroundColor(available);
                            btn.setTextColor(Color.BLACK);
                            btn.setTag("available");
                            personNumber++;
                            selectedSeats.remove(btn.getText().toString());
                            seatPersonNumberTxt.setText(personNumber + "");
                        }
                    }

                }
            });
            if(availability[j].equals("unavailable")){
                btn.setBackgroundColor(unavailable);
                btn.setTextColor(Color.BLACK);
                btn.setTag("unavailable");
                btn.setClickable(false);
            }
            row.addView(btn);
        }
        seatTable.addView(row);

    }
}
