package com.example.ozgurozdemir.test;


public class Ticket {
    public String time;
    public String id;
    public int seat;
    public String date;
    public String location;
    public Ticket(String id, String time, String date,String departure, String arrival, int seat){
        this.id = id;
        this.time = time;
        this.date = date;
        this.seat = seat;
        this.location = departure + " - " + arrival;
    }
}
