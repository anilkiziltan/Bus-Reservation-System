package com.example.ozgurozdemir.test;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.RadioButton;
import android.widget.TextView;

import java.util.ArrayList;

public class BusAdapter extends ArrayAdapter<Bus> {

    int selectedPosition = 0;

    public BusAdapter(Context context, ArrayList<Bus> buses) {
        super(context, 0, buses);

    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Get the data item for this position
        Bus bus = getItem(position);
        // Check if an existing view is being reused, otherwise inflate the view
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_bus, parent, false);
        }
        // Lookup view for data population
        RadioButton radioButton = (RadioButton) convertView.findViewById(R.id.radioButton);
        TextView timeText = (TextView) convertView.findViewById(R.id.ticketTimeTxt);
        TextView availableSeat = (TextView) convertView.findViewById(R.id.ticketAvailableSeatTxt);
        // Populate the data into the template view using the data object
        timeText.setText(bus.time);
        availableSeat.setText(bus.freeSeat + " seats are available.");
        radioButton.setChecked(position == selectedPosition);
        radioButton.setTag(position);
        radioButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                selectedPosition = (Integer)view.getTag();
                notifyDataSetChanged();
            }
        });

        // Return the completed view to render on screen
        return convertView;
    }
}