package com.example.ozgurozdemir.test;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;

public class OneWayBuyActivity extends AppCompatActivity {

    TextView oneWayBuySeatTxt;
    private Button seatButton, cancelButton;
    private ListView availableTickets;
    private int personNumber = 0;
    private String selected = "";
    private String clientName;

    private TextView oneWayfromText, oneWaytoText, oneWayDateText;

    ArrayList<Bus> arrayOfBuses = new ArrayList<Bus>();

    private Database database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buy_oneway);
        setTitle("Select Seat");

        final Intent intent = getIntent();
        personNumber = Integer.parseInt(intent.getStringExtra("personNumber"));
        selected = intent.getStringExtra("selectedPosition");

        clientName = intent.getStringExtra("clientName");

        File myDB = getApplication().getFilesDir();
        final String path = myDB +  "/" + "BusDB";
        database = new Database(path);

        oneWayBuySeatTxt = (TextView) findViewById(R.id.oneWayBuySeatTxt);
        oneWayBuySeatTxt.setText(String.format("*You have %s more seat to select", personNumber));

        oneWayfromText = (TextView) findViewById(R.id.oneWayfromText);
        oneWaytoText = (TextView) findViewById(R.id.oneWaytoText);
        oneWayDateText = (TextView) findViewById(R.id.oneWayDateText);

        oneWayfromText.setText("From: " + intent.getStringExtra("departureLocation"));
        oneWaytoText.setText("To: " + intent.getStringExtra("arrivalLocation"));
        oneWayDateText.setText("Date: " + intent.getStringExtra("departureDate"));

        availableTickets = (ListView) findViewById(R.id.oneWayAvailableTicketList);

        arrayOfBuses = database.getBuses(intent.getStringExtra("departureDate"), intent.getStringExtra("departureLocation"), intent.getStringExtra("arrivalLocation"));

        final BusAdapter adapter = new BusAdapter(this, arrayOfBuses);
        if(intent.hasExtra("selectedPosition")) {
            adapter.selectedPosition = Integer.parseInt(selected);
        }
        availableTickets.setAdapter(adapter);

        seatButton = (Button) findViewById(R.id.seatButton);
        seatButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(OneWayBuyActivity.this, SeatPopUp.class);
                //i.putExtra("selectedBus", adapter.selectedPosition + "");
                i.putExtra("personNumber", personNumber+"");
                i.putExtra("busTime", arrayOfBuses.get(adapter.selectedPosition).time);
                i.putExtra("busID", arrayOfBuses.get(adapter.selectedPosition).id);
                i.putExtra("departureLocation", intent.getStringExtra("departureLocation"));
                i.putExtra("arrivalLocation", intent.getStringExtra("arrivalLocation"));
                i.putExtra("departureDate", intent.getStringExtra("departureDate"));
                i.putExtra("ticketType", intent.getStringExtra("ticketType"));
                i.putExtra("clientName", clientName);
                i.putExtra("clientID", intent.getStringExtra("clientID"));

                startActivity(i);
            }
        });

        cancelButton = (Button) findViewById(R.id.oneWayCancelButton);
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(OneWayBuyActivity.this);
                alertDialogBuilder.setMessage("Selections before chosen will be lost, are you sure?");
                        alertDialogBuilder.setPositiveButton("yes",
                                new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface arg0, int arg1) {
                                        Intent i = new Intent(OneWayBuyActivity.this, HomeActivity.class);
                                        i.putExtra("clientName", clientName);
                                        i.putExtra("clientID", intent.getStringExtra("clientID"));
                                        startActivity(i);
                                    }
                                });

                alertDialogBuilder.setNegativeButton("No",new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.show();
            }
        });

    }
}
